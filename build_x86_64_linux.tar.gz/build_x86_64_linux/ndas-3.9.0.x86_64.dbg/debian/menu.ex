?package(ndas-1.1):needs="X11|text|vc|wm" section="Apps/see-menu-manual"\
  title="ndas-1.1" command="/usr/bin/ndas-1.1"
