#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xd8284dcd, "module_layout" },
	{ 0x20af50e0, "kmem_cache_destroy" },
	{ 0x24dffbae, "module_refcount" },
	{ 0xa7d4efb2, "kmalloc_caches" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0x8db9bc1, "sock_init_data" },
	{ 0xad73041f, "autoremove_wake_function" },
	{ 0x8351ff8f, "sock_no_ioctl" },
	{ 0x9ada752c, "sock_release" },
	{ 0xc3690fc, "_raw_spin_lock_bh" },
	{ 0xeba6c6dc, "skb_clone" },
	{ 0x3cc435ba, "dev_get_by_name" },
	{ 0x1332eb08, "skb_copy" },
	{ 0x6bd0e573, "down_interruptible" },
	{ 0xd2da1048, "register_netdevice_notifier" },
	{ 0x3235fb4d, "sock_no_getname" },
	{ 0xc29957c3, "__x86_indirect_thunk_rcx" },
	{ 0xa69dd474, "filp_close" },
	{ 0x504591a3, "sock_create_kern" },
	{ 0x409bcb62, "mutex_unlock" },
	{ 0x4629334c, "__preempt_count" },
	{ 0x97651e6c, "vmemmap_base" },
	{ 0xe914dec9, "pv_ops" },
	{ 0xd319114f, "kthread_create_on_node" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x9d0d6206, "unregister_netdevice_notifier" },
	{ 0x13ccde62, "sock_no_sendpage" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0xebb0f9c2, "sock_no_mmap" },
	{ 0x3a6db731, "sock_no_recvmsg" },
	{ 0xf69c51bc, "sock_no_socketpair" },
	{ 0xc86030f4, "sk_alloc" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0x265596c8, "current_task" },
	{ 0xe9ffc063, "down_trylock" },
	{ 0xc5850110, "printk" },
	{ 0xcf9bf49a, "sock_no_bind" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0x4c9d28b0, "phys_base" },
	{ 0xa1c76e0a, "_cond_resched" },
	{ 0x9166fada, "strncpy" },
	{ 0x6ead388, "sk_stream_wait_memory" },
	{ 0x5a921311, "strncmp" },
	{ 0x685389a4, "sock_no_listen" },
	{ 0xa8070234, "kmem_cache_free" },
	{ 0x6ca28ecb, "skb_push" },
	{ 0x2ab7989d, "mutex_lock" },
	{ 0x994d5aae, "sock_no_accept" },
	{ 0x28adf0fa, "sk_free" },
	{ 0xb0a35c36, "dev_remove_pack" },
	{ 0x33e2da53, "init_net" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0x346b74a5, "sock_no_shutdown" },
	{ 0x9fe68f2e, "flush_signals" },
	{ 0x7cd8d75e, "page_offset_base" },
	{ 0xfd38c450, "kmem_cache_alloc" },
	{ 0xfbd194d6, "__alloc_skb" },
	{ 0xe46021ca, "_raw_spin_unlock_bh" },
	{ 0x296695f, "refcount_warn_saturate" },
	{ 0xc959d152, "__stack_chk_fail" },
	{ 0x23db0cf, "datagram_poll" },
	{ 0x5368927a, "sock_register" },
	{ 0x1000e51, "schedule" },
	{ 0x8ddd8aad, "schedule_timeout" },
	{ 0x8143c8f3, "kfree_skb" },
	{ 0xfb6af58d, "recalc_sigpending" },
	{ 0x6b2dc060, "dump_stack" },
	{ 0x2ea2c95c, "__x86_indirect_thunk_rax" },
	{ 0xd864ab08, "sock_alloc_send_skb" },
	{ 0xcb029e2f, "wake_up_process" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x23a58451, "kmem_cache_alloc_trace" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0x269d5407, "kmem_cache_create" },
	{ 0x9ea53d7f, "vsnprintf" },
	{ 0x3eeb2322, "__wake_up" },
	{ 0x8c26d495, "prepare_to_wait_event" },
	{ 0x38e36ee1, "sock_no_connect" },
	{ 0x37a0cba, "kfree" },
	{ 0xd5fd90f1, "prepare_to_wait" },
	{ 0x62737e1d, "sock_unregister" },
	{ 0x43063da9, "sock_no_sendmsg" },
	{ 0xcf2a6966, "up" },
	{ 0xb0839199, "set_user_nice" },
	{ 0x92540fbf, "finish_wait" },
	{ 0x40c1bdcd, "dev_add_pack" },
	{ 0x3837b3dd, "dev_queue_xmit" },
	{ 0x1994a9bd, "skb_put" },
	{ 0x77854461, "filp_open" },
};

MODULE_INFO(depends, "");

