#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xd8284dcd, "module_layout" },
	{ 0x6bc3fbc0, "__unregister_chrdev" },
	{ 0x2a64d3ae, "ndas_register_device" },
	{ 0xac413c3e, "ndas_disable_slot" },
	{ 0xa5a7802a, "ndas_set_slot_handlers" },
	{ 0x59a4c052, "ndas_query_slot" },
	{ 0x3222c12f, "ndas_enable_slot" },
	{ 0xffde233e, "device_destroy" },
	{ 0x6729d3df, "__get_user_4" },
	{ 0xc02647b9, "__register_chrdev" },
	{ 0x81539954, "ndas_registered_list" },
	{ 0x228c1e9, "ndas_probed_size" },
	{ 0xa6ce8f48, "ndas_set_registration_name" },
	{ 0x8ab26b19, "ndas_query_unit" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0x771527c9, "ndas_set_device_change_handler" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0xe5410774, "ndas_unregister_device" },
	{ 0x4387044a, "sal_malloc" },
	{ 0xc5850110, "printk" },
	{ 0xbfdbe6db, "ndas_probed_list" },
	{ 0xfcffb1d4, "ndas_get_ndas_dev_info" },
	{ 0x6626afca, "down" },
	{ 0xca533cc3, "device_create" },
	{ 0x1b71c3eb, "ndas_registered_size" },
	{ 0xbd6d9157, "ndas_enable_writeshare" },
	{ 0x189cfaf1, "ndas_detect_device" },
	{ 0xbfcec02d, "module_put" },
	{ 0xc6cbbc89, "capable" },
	{ 0xb2fd5ceb, "__put_user_4" },
	{ 0xa557de79, "ndas_stop" },
	{ 0xae693230, "sal_free" },
	{ 0x3306c43a, "ndas_start" },
	{ 0xc959d152, "__stack_chk_fail" },
	{ 0x6d334118, "__get_user_8" },
	{ 0xbb9b5bd9, "ndas_register_device_by_serial" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xcf2a6966, "up" },
	{ 0x39e049db, "class_destroy" },
	{ 0xe480acb7, "ndas_query_ndas_id_by_serial" },
	{ 0xb2b126b9, "ndas_enable_exclusive_writable" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x68aa5bad, "__class_create" },
	{ 0x46ad1cc8, "ndas_request_permission" },
	{ 0x25bbe2ce, "try_module_get" },
};

MODULE_INFO(depends, "ndas_core,ndas_sal");

