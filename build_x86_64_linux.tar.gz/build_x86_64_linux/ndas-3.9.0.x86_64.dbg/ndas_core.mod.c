#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xd8284dcd, "module_layout" },
	{ 0xce58bfbe, "sal_netdev_unregister_proto" },
	{ 0xc2a5a50a, "sal_get_tick" },
	{ 0x56639aab, "sal_msleep" },
	{ 0x3a1ba474, "sal_thread_block_signals" },
	{ 0x49b4e422, "param_ops_int" },
	{ 0x4fe2725e, "sal_free_from_pool" },
	{ 0x754d539c, "strlen" },
	{ 0x19e4a549, "sal_netdev_open" },
	{ 0x2614e9be, "sal_alloc_from_pool" },
	{ 0x2e54678a, "sal_dump_stack" },
	{ 0x612e64ca, "sal_debug_println_impl" },
	{ 0x14853b16, "sal_thread_exit" },
	{ 0x9716fde3, "sal_snprintf" },
	{ 0xfe8c61f0, "_raw_read_lock" },
	{ 0xe309d0a7, "sal_time_msec" },
	{ 0x25f4ed8f, "sal_debug_print" },
	{ 0x356ad217, "sal_netdev_register_proto" },
	{ 0xa5976e4f, "dev_base_lock" },
	{ 0xf5ea9483, "sal_netdev_close" },
	{ 0x52961b66, "sal_semaphore_create" },
	{ 0x6106fdbd, "sal_net_set_change_handler" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x6927b58f, "sal_spinlock_create" },
	{ 0x7379e981, "param_ops_charp" },
	{ 0xf42c74, "sal_net_clone_platform_buf" },
	{ 0xfb578fc5, "memset" },
	{ 0xe4946a1e, "sal_atomic_inc" },
	{ 0x7446c746, "sal_atomic_dec" },
	{ 0x4387044a, "sal_malloc" },
	{ 0xc5850110, "printk" },
	{ 0x8b1e61d2, "sal_net_alloc_buf_bufseg" },
	{ 0x449ad0a7, "memcmp" },
	{ 0x5552fb4, "sal_semaphore_destroy" },
	{ 0xbda4d931, "sal_spinlock_take_softirq" },
	{ 0xebc17d4d, "sal_error_print" },
	{ 0x714a3e1e, "sal_spinlock_destroy" },
	{ 0x2daf86ed, "sal_process_page_to_net_buf_mapping" },
	{ 0x9f94b479, "SAL_TICKS_PER_SEC" },
	{ 0x33e2da53, "init_net" },
	{ 0x1ddd03e1, "sal_create_mem_pool" },
	{ 0xc4b11a8c, "sal_netdev_get_mtu" },
	{ 0xf1e4bf7d, "sal_event_destroy" },
	{ 0x98dd60a1, "sal_netdev_get_address" },
	{ 0xc0ca5c91, "sal_event_reset" },
	{ 0xc68e761c, "sal_semaphore_take" },
	{ 0xbd38e893, "sal_net_alloc_platform_buf_ex" },
	{ 0x468d896c, "sal_net_is_platform_buf_shared" },
	{ 0xb707f784, "sal_net_free_platform_buf" },
	{ 0x7e2aef29, "sal_atomic_dec_and_test" },
	{ 0xae693230, "sal_free" },
	{ 0x21ca3dbf, "sal_event_set" },
	{ 0x43c4bf96, "sal_sock_destroy" },
	{ 0xf21b3342, "sal_spinlock_take" },
	{ 0x63e101b0, "sal_destroy_mem_pool" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x531ece44, "sal_event_wait" },
	{ 0x501a90f6, "sal_gethostname" },
	{ 0xb4768fd0, "sal_sock_create" },
	{ 0xd5aedb94, "sal_thread_nice" },
	{ 0x69acdf38, "memcpy" },
	{ 0x513a5b29, "sal_thread_create" },
	{ 0xb3e6c9f6, "sal_event_create" },
	{ 0xcd8e8802, "sal_ether_send" },
	{ 0xc69143aa, "sal_thread_daemonize" },
	{ 0x43259de3, "sal_spinlock_give" },
	{ 0x5b666cc5, "sal_semaphore_give" },
	{ 0xee8ed966, "sal_net_copy_platform_buf" },
	{ 0xdf00d169, "sal_spinlock_give_softirq" },
};

MODULE_INFO(depends, "ndas_sal");

